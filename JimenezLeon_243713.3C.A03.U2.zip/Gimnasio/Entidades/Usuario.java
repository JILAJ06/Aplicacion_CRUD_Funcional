package Entidades;

public class Usuario {
    protected String nombre;
    protected String apellido;
    protected String identificador;
    protected String contacto;

    public Usuario(String nombre, String apellido, String identificador, String contacto) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.identificador = identificador;
        this.contacto = contacto;
    }

    // Getters and setters
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    
    public String getApellidos() { return apellido; }
    public void setApellidos(String apellido) { this.apellido = apellido; }
    
    public String getIdentificador() { return identificador; }
    public void setIdentificador(String identificador) { this.identificador = identificador; }
    
    public String getContacto() { return contacto; }
    public void setContacto(String contacto) { this.contacto = contacto; }
}
