package Entidades;

public class Subscriptor extends Usuario {
    private String numeroMembresia;
    private boolean activo;
    private String nivel;

    public Subscriptor(String nombre, String apellido, String identificador, String contacto,
                      String numeroMembresia, boolean activo, String nivel) {
        super(nombre, apellido, identificador, contacto);
        this.numeroMembresia = numeroMembresia;
        this.activo = activo;
        this.nivel = nivel;
    }

    // Getters and setters
    public String getNumeroMembresia() { return numeroMembresia; }
    public void setNumeroMembresia(String numeroMembresia) { this.numeroMembresia = numeroMembresia; }
    
    public boolean isActivo() { return activo; }
    public void setActivo(boolean activo) { this.activo = activo; }
    
    public String getNivel() { return nivel; }
    public void setNivel(String nivel) { this.nivel = nivel; }
}
