package Entidades;

public class Instructor extends Usuario {
    private String numeroInstructor;

    public Instructor(String nombre, String apellido, String identificador, String contacto,
                     String numeroInstructor) {
        super(nombre, apellido, identificador, contacto);
        this.numeroInstructor = numeroInstructor;
    }

    // Getters and setters
    public String getNumeroInstructor() { return numeroInstructor; }
    public void setNumeroInstructor(String numeroInstructor) { this.numeroInstructor = numeroInstructor; }
}
