package Entidades;

public class Curso {
    private String numeroCurso;
    private String periodoCurso;
    private String informacionGeneral;
    private Instructor instructor;

    public Curso(String numeroCurso, String periodoCurso, String informacionGeneral, Instructor instructor) {
        this.numeroCurso = numeroCurso;
        this.periodoCurso = periodoCurso;
        this.informacionGeneral = informacionGeneral;
        this.instructor = instructor;
    }

    // Getters and setters
    public String getNumeroCurso() { return numeroCurso; }
    public void setNumeroCurso(String numeroCurso) { this.numeroCurso = numeroCurso; }
    
    public String getPeriodoCurso() { return periodoCurso; }
    public void setPeriodoCurso(String periodoCurso) { this.periodoCurso = periodoCurso; }
    
    public String getInformacionGeneral() { return informacionGeneral; }
    public void setInformacionGeneral(String informacionGeneral) { this.informacionGeneral = informacionGeneral; }
    
    public Instructor getInstructor() { return instructor; }
    public void setInstructor(Instructor instructor) { this.instructor = instructor; }
}