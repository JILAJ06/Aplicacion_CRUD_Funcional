package CRUD;
import java.sql.*;
import java.util.Scanner;

public class SubscriptorCRUD {
    public static void crearSubscriptor(Connection conn, Scanner scanner) {
        try {
            System.out.print("Nombre: ");
            String nombre = scanner.nextLine();
            System.out.print("Apellido: ");
            String apellido = scanner.nextLine();
            System.out.print("Teléfono: ");
            String telefono = scanner.nextLine();
            System.out.print("Correo: ");
            String correo = scanner.nextLine();
            System.out.print("Fecha inicio (YYYY-MM-DD): ");
            String fechaInicio = scanner.nextLine();
            System.out.print("Fecha fin (YYYY-MM-DD): ");
            String fechaFin = scanner.nextLine();
            System.out.print("Membresía activa (true/false): ");
            boolean activa = scanner.nextBoolean();
            scanner.nextLine();

            String sql = "INSERT INTO subscriptores (nombre, apellido, telefono, correo, fechaInicio, fechaFin, membresiaActiva) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, nombre);
            stmt.setString(2, apellido);
            stmt.setString(3, telefono);
            stmt.setString(4, correo);
            stmt.setString(5, fechaInicio);
            stmt.setString(6, fechaFin);
            stmt.setBoolean(7, activa);
            stmt.executeUpdate();

            System.out.println("Subscriptor creado exitosamente.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void listarSubscriptores(Connection conn) {
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM subscriptores");

            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("id") +
                                   ", Nombre: " + rs.getString("nombre") +
                                   ", Membresía activa: " + rs.getBoolean("membresiaActiva"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void actualizarSubscriptor(Connection conn, Scanner scanner) {
        try {
            System.out.print("ID del subscriptor a actualizar: ");
            int id = scanner.nextInt();
            scanner.nextLine();

            System.out.print("Nueva fecha fin (YYYY-MM-DD): ");
            String nuevaFechaFin = scanner.nextLine();

            String sql = "UPDATE subscriptores SET fechaFin = ? WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, nuevaFechaFin);
            stmt.setInt(2, id);
            stmt.executeUpdate();

            System.out.println("Subscriptor actualizado.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void eliminarSubscriptor(Connection conn, Scanner scanner) {
        try {
            System.out.print("ID del subscriptor a eliminar: ");
            int id = scanner.nextInt();
            scanner.nextLine();

            String sql = "DELETE FROM subscriptores WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.executeUpdate();

            System.out.println("Subscriptor eliminado.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
