package CRUD;

import java.sql.*;
import java.util.Scanner;

public class InscripcionCRUD {
    public static void inscribirSubscriptor(Connection conn, Scanner scanner) {
        try {
            System.out.print("ID del subscriptor: ");
            int subscriptorId = scanner.nextInt();
            System.out.print("ID del curso: ");
            int cursoId = scanner.nextInt();
            scanner.nextLine(); 

            String sql = "INSERT INTO inscripciones (subscriptor_id, curso_id) VALUES (?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, subscriptorId);
            stmt.setInt(2, cursoId);
            stmt.executeUpdate();

            System.out.println("Subscriptor inscrito correctamente al curso.");
        } catch (SQLIntegrityConstraintViolationException e) {
            System.out.println("⚠️ Ya está inscrito o los IDs no existen.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void listarInscripciones(Connection conn) {
        try {
            String sql = """
                SELECT s.nombre AS subscriptor, c.nombre AS curso, i.fecha_inscripcion
                FROM inscripciones i
                JOIN subscriptores s ON i.subscriptor_id = s.id
                JOIN cursos c ON i.curso_id = c.id
            """;

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            System.out.println("\n--- Inscripciones ---");
            while (rs.next()) {
                System.out.println("Subscriptor: " + rs.getString("subscriptor") +
                                   " | Curso: " + rs.getString("curso") +
                                   " | Fecha: " + rs.getDate("fecha_inscripcion"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
