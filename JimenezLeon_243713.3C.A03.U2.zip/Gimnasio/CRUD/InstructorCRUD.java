package CRUD;
import java.sql.*;
import java.util.Scanner;

public class InstructorCRUD {
    public static void crearInstructor(Connection conn, Scanner scanner) {
        try {
            System.out.print("Nombre: ");
            String nombre = scanner.nextLine();
            System.out.print("Apellido: ");
            String apellido = scanner.nextLine();
            System.out.print("Teléfono: ");
            String telefono = scanner.nextLine();
            System.out.print("Correo: ");
            String correo = scanner.nextLine();
            System.out.print("Especialidad: ");
            String especialidad = scanner.nextLine();

            String sql = "INSERT INTO instructores (nombre, apellido, telefono, correo, especialidad) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, nombre);
            stmt.setString(2, apellido);
            stmt.setString(3, telefono);
            stmt.setString(4, correo);
            stmt.setString(5, especialidad);
            stmt.executeUpdate();

            System.out.println("Instructor creado exitosamente.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void listarInstructores(Connection conn) {
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM instructores");

            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("id") +
                                   ", Nombre: " + rs.getString("nombre") +
                                   ", Especialidad: " + rs.getString("especialidad"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void actualizarInstructor(Connection conn, Scanner scanner) {
        try {
            System.out.print("ID del instructor a actualizar: ");
            int id = scanner.nextInt();
            scanner.nextLine();

            System.out.print("Nueva especialidad: ");
            String especialidad = scanner.nextLine();

            String sql = "UPDATE instructores SET especialidad = ? WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, especialidad);
            stmt.setInt(2, id);
            stmt.executeUpdate();

            System.out.println("Instructor actualizado.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void eliminarInstructor(Connection conn, Scanner scanner) {
        try {
            System.out.print("ID del instructor a eliminar: ");
            int id = scanner.nextInt();
            scanner.nextLine();

            String sql = "DELETE FROM instructores WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.executeUpdate();

            System.out.println("Instructor eliminado.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
