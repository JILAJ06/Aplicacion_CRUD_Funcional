package CRUD;
import java.sql.*;
import java.util.Scanner;

public class CursoCRUD {
    public static void crearCurso(Connection conn, Scanner scanner) {
        try {
            System.out.print("Nombre del curso: ");
            String nombre = scanner.nextLine();
            System.out.print("Descripción: ");
            String descripcion = scanner.nextLine();
            System.out.print("Fecha de inicio (YYYY-MM-DD): ");
            String fechaInicio = scanner.nextLine();
            System.out.print("Fecha de fin (YYYY-MM-DD): ");
            String fechaFin = scanner.nextLine();
            System.out.print("ID del instructor: ");
            int instructorId = scanner.nextInt();
            scanner.nextLine(); 

            String sql = "INSERT INTO cursos (nombre, descripcion, fechaInicio, fechaFin, instructor_id) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, nombre);
            stmt.setString(2, descripcion);
            stmt.setString(3, fechaInicio);
            stmt.setString(4, fechaFin);
            stmt.setInt(5, instructorId);
            stmt.executeUpdate();

            System.out.println("Curso creado exitosamente.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void listarCursos(Connection conn) {
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(
                "SELECT c.*, i.nombre as instructor_nombre, i.apellido as instructor_apellido " +
                "FROM cursos c JOIN instructores i ON c.instructor_id = i.id");

            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("id") +
                                   ", Nombre: " + rs.getString("nombre") +
                                   ", Instructor: " + rs.getString("instructor_nombre") + " " + rs.getString("instructor_apellido"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void actualizarCurso(Connection conn, Scanner scanner) {
        try {
            System.out.print("ID del curso a actualizar: ");
            int id = scanner.nextInt();
            scanner.nextLine(); 
            System.out.print("Nuevo nombre: ");
            String nombre = scanner.nextLine();
            System.out.print("Nueva descripción: ");
            String descripcion = scanner.nextLine();

            String sql = "UPDATE cursos SET nombre = ?, descripcion = ? WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, nombre);
            stmt.setString(2, descripcion);
            stmt.setInt(3, id);
            stmt.executeUpdate();

            System.out.println("Curso actualizado.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void eliminarCurso(Connection conn, Scanner scanner) {
        try {
            System.out.print("ID del curso a eliminar: ");
            int id = scanner.nextInt();
            scanner.nextLine(); 

            String sql = "DELETE FROM cursos WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.executeUpdate();

            System.out.println("Curso eliminado.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
