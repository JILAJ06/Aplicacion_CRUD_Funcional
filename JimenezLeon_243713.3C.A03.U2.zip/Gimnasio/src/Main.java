package src;
import CRUD.CursoCRUD;
import CRUD.InscripcionCRUD;
import CRUD.InstructorCRUD;
import CRUD.SubscriptorCRUD;

import java.sql.*;
import java.util.Scanner;


import BaseDeDatos.DatabaseConnection;

public class Main {
    private static Connection conn;

    public static void main(String[] args) throws SQLException {
        conn = DatabaseConnection.getConnection();
        if (conn == null) {
            System.out.println("Error al conectar con la base de datos.");
            return;
        }
        
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\n=== MENÚ PRINCIPAL ===");
            System.out.println("1. Gestionar Cursos");
            System.out.println("2. Gestionar Instructores");
            System.out.println("3. Gestionar Subscriptores");
            System.out.println("4. Inscripciones");
            System.out.println("0. Salir");
            System.out.print("Elige una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); 

            switch (opcion) {
                case 1:
                    menuCurso(scanner);
                    break;
                case 2:
                    menuInstructor(scanner);
                    break;
                case 3:
                    menuSubscriptor(scanner);
                    break;
                case 4:
                    menuInscripciones(scanner);
                    break;
                case 0:
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        } while (opcion != 0);

        scanner.close();
    }

    private static void menuCurso(Scanner scanner) {
        int opcion;
        do {
            System.out.println("\n--- CRUD Curso ---");
            System.out.println("1. Crear curso");
            System.out.println("2. Listar cursos");
            System.out.println("3. Actualizar curso");
            System.out.println("4. Eliminar curso");
            System.out.println("0. Volver");
            System.out.print("Elige una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1 -> CursoCRUD.crearCurso(conn, scanner);
                case 2 -> CursoCRUD.listarCursos(conn);
                case 3 -> CursoCRUD.actualizarCurso(conn, scanner);
                case 4 -> CursoCRUD.eliminarCurso(conn, scanner);
                case 0 -> System.out.println("Volviendo al menú principal...");
                default -> System.out.println("Opción inválida.");
            }
        } while (opcion != 0);
    }

    private static void menuInstructor(Scanner scanner) {
        int opcion;
        do {
            System.out.println("\n--- CRUD Instructor ---");
            System.out.println("1. Crear instructor");
            System.out.println("2. Listar instructores");
            System.out.println("3. Actualizar instructor");
            System.out.println("4. Eliminar instructor");
            System.out.println("0. Volver");
            System.out.print("Elige una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1 -> InstructorCRUD.crearInstructor(conn, scanner);
                case 2 -> InstructorCRUD.listarInstructores(conn);
                case 3 -> InstructorCRUD.actualizarInstructor(conn, scanner);
                case 4 -> InstructorCRUD.eliminarInstructor(conn, scanner);
                case 0 -> System.out.println("Volviendo al menú principal...");
                default -> System.out.println("Opción inválida.");
            }
        } while (opcion != 0);
    }

    private static void menuSubscriptor(Scanner scanner) {
        int opcion;
        do {
            System.out.println("\n--- CRUD Subscriptor ---");
            System.out.println("1. Crear subscriptor");
            System.out.println("2. Listar subscriptores");
            System.out.println("3. Actualizar subscriptor");
            System.out.println("4. Eliminar subscriptor");
            System.out.println("0. Volver");
            System.out.print("Elige una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1 -> SubscriptorCRUD.crearSubscriptor(conn, scanner);
                case 2 -> SubscriptorCRUD.listarSubscriptores(conn);
                case 3 -> SubscriptorCRUD.actualizarSubscriptor(conn, scanner);
                case 4 -> SubscriptorCRUD.eliminarSubscriptor(conn, scanner);
                case 0 -> System.out.println("Volviendo al menú principal...");
                default -> System.out.println("Opción inválida.");
            }
        } while (opcion != 0);
    }

    private static void menuInscripciones(Scanner scanner) {
    int opcion;
    do {
        System.out.println("\n--- GESTIÓN DE INSCRIPCIONES ---");
        System.out.println("1. Inscribir subscriptor a curso");
        System.out.println("2. Ver inscripciones");
        System.out.println("0. Volver");
        System.out.print("Elige una opción: ");
        opcion = scanner.nextInt();
        scanner.nextLine();

        switch (opcion) {
            case 1 -> InscripcionCRUD.inscribirSubscriptor(conn, scanner);
            case 2 -> InscripcionCRUD.listarInscripciones(conn);
            case 0 -> System.out.println("Volviendo al menú principal...");
            default -> System.out.println("Opción inválida.");
        }
    } while (opcion != 0);
}

}
